console.log('OMG, my shortcode is used!');
